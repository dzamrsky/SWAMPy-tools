"""

Functions for plotting and viewing borehole data.

"""

import sys
from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow, QAction, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QSpacerItem, QSizePolicy, QPushButton, QSlider, QListWidget
from PyQt5.QtGui import QIcon, QBrush, QColor
from PyQt5.QtCore import QSize, QAbstractListModel, Qt, QModelIndex
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
#import random
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT
import matplotlib
import matplotlib.patches as mpatches
from matplotlib.colors import ListedColormap
from matplotlib.patches import Rectangle
matplotlib.use("Qt5Agg")
import numpy as np
from .. import xarray as xr
import math
import os


#   create the tableview class
class BoreholeListTable(QAbstractListModel):
    def __init__(self, borehole_list=None):
        super().__init__()
        #   set the model list to be empty
        self.borehole_list = borehole_list or []

    def data(self, index, role):
        if role == Qt.DisplayRole:
            text = self.borehole_list[index.row()]

            return text
        if role == Qt.TextAlignmentRole:
            return Qt.AlignCenter

    def rowCount(self, index):
        return len(self.borehole_list)

#   plot the borehole - the original version with original depths and classes, and the database version
#       out_dir: directory where the plots will be saved
#       borehole_name: name of the plot (borehole)
#       litho_classes_dict: dictionary with the lithology classes and their plotting style
#       orig_from_dph_lst: list of original from depths
#       orig_to_dph_lst: list of original to depths
#       orig_litho_lst: list of original lithological classes (matching the from - to depths)
#       dbase_from_dph_lst: list of database from depths
#       dbase_to_dph_lst: list of database to depths
#       dbase_litho_lst: list of database lithological classes (matching the from - to depths)

def plot_borehole(out_dir, borehole_name, litho_lst, litho_classes_dict, orig_from_dph_lst, orig_to_dph_lst,
                  orig_litho_lst, \
                  dbase_from_dph_lst, dbase_to_dph_lst, dbase_litho_lst):
    #   define the sublots in the figure
    fig = plt.Figure(figsize=(8, 12), dpi=500)
    ax1 = plt.subplot2grid((4, 4), (0, 0), colspan=4, fig=fig)  # title
    ax2 = plt.subplot2grid((4, 4), (1, 0), colspan=2, fig=fig)  # orig litho classes title
    ax3 = plt.subplot2grid((4, 4), (2, 0), fig=fig)  # orig litho classes names
    ax4 = plt.subplot2grid((4, 4), (2, 1), fig=fig)  # orig borehole
    ax5 = plt.subplot2grid((4, 4), (1, 2), colspan=2, fig=fig)  # dbase litho classes title
    ax6 = plt.subplot2grid((4, 4), (2, 3), fig=fig)  # dbase litho classes names
    ax7 = plt.subplot2grid((4, 4), (2, 2), fig=fig)  # dbase borehole
    ax8 = plt.subplot2grid((4, 4), (3, 0), colspan=4, fig=fig)  # legend

    #   specify the location of each of these figure parts
    ax1.set_position([0.05, 0.95, 0.9, 0.045])  # [left, bottom, width, height]
    ax2.set_position([0.05, 0.905, 0.44, 0.04])
    ax3.set_position([0.05, 0.2, 0.325, 0.7])
    ax4.set_position([0.4, 0.2, 0.09, 0.7])
    ax5.set_position([0.51, 0.905, 0.44, 0.04])
    ax6.set_position([0.62, 0.2, 0.325, 0.7])
    ax7.set_position([0.51, 0.2, 0.09, 0.7])
    ax8.set_position([0.075, 0.025, 0.9, 0.155])

    #   set the titles
    txt = ax1.text(0.5, 0.5, 'Borehole ' + borehole_name, fontsize=18, fontweight='bold', ha='center', va='center')
    txt.set_clip_on(False)
    ax1.axis('off')

    txt = ax2.text(0.5, 0.5, 'Original lithology', fontsize=11, fontweight='bold', ha='center', va='center')
    txt.set_clip_on(False)
    ax2.axis('off')

    txt = ax5.text(0.5, 0.5, 'Database lithology', fontsize=11, fontweight='bold', ha='center', va='center')
    txt.set_clip_on(False)
    ax5.axis('off')

    #   plot the depths of the original borehole lithology
    ax4.plot()
    ax4.set_xlim(0, 1)
    ax4.set_ylim(0, dbase_to_dph_lst[-1])
    ax4.spines["top"].set_edgecolor("black")
    ax4.invert_yaxis()

    ax3.set_xlim(0, 1)
    ax3.set_ylim(0, dbase_to_dph_lst[-1])
    ax3.invert_yaxis()
    ax3.axis('off')

    for k in range(len(orig_litho_lst)):
        key = litho_lst[k]
        #   find color, hatch and the depth from and to for given litho class
        color = litho_classes_dict[key]['color']
        hatch = litho_classes_dict[key]['hatch']
        y_coord = [orig_from_dph_lst[k], orig_to_dph_lst[k]]
        ax4.fill_betweenx(y_coord, 0, [1, 1], facecolor=color, hatch=hatch)
        ax4.plot([0, 1], [orig_from_dph_lst[k], orig_from_dph_lst[k]], color='blue', lw=1.5)
        ax4.plot([0, 1], [orig_to_dph_lst[k], orig_to_dph_lst[k]], color='blue', lw=1.5)
        ax3.text(0.9, orig_from_dph_lst[k] - (orig_from_dph_lst[k] - orig_to_dph_lst[k]) / 2., orig_litho_lst[k],
                 size=10, color='black', horizontalalignment='right', va='center')
    ax4.set_xticks([])

    ax7.plot()
    ax7.set_xlim(0, 1)
    ax7.set_ylim(0, dbase_to_dph_lst[-1])
    ax7.spines["top"].set_edgecolor("black")
    ax7.invert_yaxis()
    ax7.yaxis.tick_right()

    ax6.set_xlim(0, 1)
    ax6.set_ylim(0, dbase_to_dph_lst[-1])
    ax6.invert_yaxis()
    ax6.axis('off')

    for k in range(len(dbase_litho_lst)):
        key = dbase_litho_lst[k]
        #   find color, hatch and the depth from and to for given litho class
        color = litho_classes_dict[key]['color']
        hatch = litho_classes_dict[key]['hatch']
        y_coord = [dbase_from_dph_lst[k], dbase_to_dph_lst[k]]
        ax7.fill_betweenx(y_coord, 0, [1, 1], facecolor=color, hatch=hatch)
        ax7.plot([0, 1], [dbase_from_dph_lst[k], dbase_from_dph_lst[k]], color='blue', lw=1.5)
        ax7.plot([0, 1], [dbase_to_dph_lst[k], dbase_to_dph_lst[k]], color='blue', lw=1.5)
        ax6.text(0.1, dbase_from_dph_lst[k] - (dbase_from_dph_lst[k] - dbase_to_dph_lst[k]) / 2.,
                 key + ': ' + litho_classes_dict[key]['lith_full'], size=10, color='black', horizontalalignment='left',
                 va='center')
    ax7.set_xticks([])

    #   create legend from the dictionary
    patchList = []
    for key in litho_classes_dict:
        data_key = mpatches.Patch(facecolor=litho_classes_dict[key]['color'], hatch=litho_classes_dict[key]['hatch'],
                                  label=litho_classes_dict[key]['lith'] + ': ' + litho_classes_dict[key]['lith_full'])
        patchList.append(data_key)

    #   define the legend
    legend = ax8.legend(handles=patchList, ncol=4, frameon=True, fontsize=7, handlelength=3, labelspacing=1.75,
                        title="Database lithological classification", title_fontsize=10)
    legend.get_frame().set_edgecolor('black')
    legend.get_frame().set_linewidth(.75)
    ax8.axis('off')

    #   define the size of the patches (rectangles) showing the lithology classes
    for patch in legend.get_patches():
        patch.set_height(16)
        patch.set_y(-4)

    #   save the figurr
    # out_png = r'g:\_HyGS\_database\borelog_test.png'
    out_png = os.path.join(out_dir, borehole_name + '.png')
    canvas = FigureCanvas(fig)
    canvas.print_figure(out_png)


#   define class for the plotting area
class BoreholePlotCanvas(FigureCanvas):

    def __init__(self, parent=None, width=4, height=12, dpi=300):

        #   define the lithological classes styles and names
        self.litho_class_styles = {
            'su': {'lith': 'su', 'lith_full': 'unconsolidated sediments', 'lith_num': 100, 'hatch': '',
                   'color': 'gold'},
            'su_ad': {'lith': 'su_ad', 'lith_full': 'alluvial deposits', 'lith_num': 101, 'hatch': '-.',
                      'color': '#ffd757'},
            'su_ds': {'lith': 'su_ds', 'lith_full': 'dune sands', 'lith_num': 102, 'hatch': '-.', 'color': '#fcc100'},
            'su_lo': {'lith': 'su_lo', 'lith_full': 'loess', 'lith_num': 103, 'hatch': '-.', 'color': '#8a6a00'},
            'su_mx': {'lith': 'su_mx', 'lith_full': 'sand - mixed grain size', 'lith_num': 104, 'hatch': 'O',
                      'color': '#ffd95f'},
            'su_ss': {'lith': 'su_ss', 'lith_full': 'sand - coarse grained', 'lith_num': 105, 'hatch': 'o',
                      'color': '#ffd95f'},
            'su_sh': {'lith': 'su_sh', 'lith_full': 'sand - fine grained', 'lith_num': 106, 'hatch': '.',
                      'color': '#ffd95f'},
            'su_cl': {'lith': 'su_cl', 'lith_full': 'clay', 'lith_num': 107, 'hatch': '.', 'color': 'grey'},
            'su_gr': {'lith': 'su_gr', 'lith_full': 'gravel', 'lith_num': 108, 'hatch': 'o', 'color': 'olivedrab'},
            'su_sl': {'lith': 'su_sl', 'lith_full': 'silt', 'lith_num': 109, 'hatch': '..', 'color': 'lawngreen'},
            'ss': {'lith': 'ss', 'lith_full': 'siliclastic sedimentary rocks', 'lith_num': 200, 'hatch': '',
                   'color': 'forestgreen'},
            'ss_gr': {'lith': 'ss_gr', 'lith_full': 'siliclastic sedimentary rocks -\ncoarse grained (conglomerate)',
                      'lith_num': 201, 'hatch': 'o', 'color': 'forestgreen'},
            'ss_mx': {'lith': 'ss_ss', 'lith_full': 'siliclastic sedimentary rocks -\nmedium grained (sandstone)',
                      'lith_num': 202, 'hatch': 'O', 'color': 'forestgreen'},
            'ss_cl': {'lith': 'ss_cl', 'lith_full': 'siliclastic sedimentary rocks -\nfine grained (mudstone)',
                      'lith_num': 203, 'hatch': '.', 'color': 'forestgreen'},
            'sm': {'lith': 'sm', 'lith_full': 'mixed sedimentary rocks', 'lith_num': 210, 'hatch': 'o-',
                   'color': 'turquoise'},
            'sc': {'lith': 'sc', 'lith_full': 'carbonate sedimentary rocks', 'lith_num': 220, 'hatch': 'o-',
                   'color': 'aqua'},
            'sc_we': {'lith': 'sc_we', 'lith_full': 'carbonate sedimentary rocks -\nweathered', 'lith_num': 221, 'hatch': 'x',
                   'color': 'aqua'},
            'vb': {'lith': 'vb', 'lith_full': 'basic volcanic rocks', 'lith_num': 300, 'hatch': 'o',
                   'color': 'darkorange'},
            'vi': {'lith': 'vi', 'lith_full': 'intermediate volcanic rocks', 'lith_num': 310, 'hatch': 'O',
                   'color': 'darkorange'},
            'va': {'lith': 'va', 'lith_full': 'acid volcanic rocks', 'lith_num': 320, 'hatch': 'oo',
                   'color': 'darkorange'},
            'pb': {'lith': 'pb', 'lith_full': 'basic plutonic rocks', 'lith_num': 400, 'hatch': 'o',
                   'color': 'fuchsia'},
            'pi': {'lith': 'pi', 'lith_full': 'intermediate plutonic rocks', 'lith_num': 410, 'hatch': 'O',
                   'color': 'fuchsia'},
            'pa': {'lith': 'pa', 'lith_full': 'acid plutonic rocks', 'lith_num': 420, 'hatch': 'oo',
                   'color': 'fuchsia'},
            'mt': {'lith': 'mt', 'lith_full': 'metamorphic rocks', 'lith_num': 500, 'hatch': '-|', 'color': 'plum'},
            'mt_am': {'lith': 'mt_am', 'lith_full': 'mafic metamorphic rocks', 'lith_num': 501, 'hatch': 'x', 'color': 'plum'},
            'py': {'lith': 'py', 'lith_full': 'pyroclastics', 'lith_num': 600, 'hatch': 'x', 'color': 'crimson'},
            'ev': {'lith': 'ev', 'lith_full': 'evaporites', 'lith_num': 700, 'hatch': 'o', 'color': 'darkorchid'},
            'rock': {'lith': 'rock', 'lith_full': 'rock', 'lith_num': 800, 'hatch': '++', 'color': 'dimgrey'},
            'soil': {'lith': 'soil', 'lith_full': 'soil', 'lith_num': 900, 'hatch': 'o', 'color': 'tan'},
            'coal': {'lith': 'coal', 'lith_full': 'coal', 'lith_num': 1000, 'hatch': '-|', 'color': 'black'},
            'nd': {'lith': 'nd', 'lith_full': 'not defined', 'lith_num': 0, 'hatch': 'x', 'color': 'snow'}}
        #   define the sublots in the figure
        self.fig = plt.Figure(figsize=(4, 12))
        self.ax1 = plt.subplot2grid((2, 1), (0, 0), fig=self.fig)  # dbase borehole
        self.ax2 = plt.subplot2grid((2, 1), (1, 0), fig=self.fig)  # dbase borehole
        self.ax1.set_position([0.2, 0.05, 0.6, 0.9])  # [left, bottom, width, height]
        self.ax2.set_position([0.01, 0.05, 0.05, 0.9])  # [left, bottom, width, height]
        #   define the label for the Y legend which is depth below surface level (m)
        txt = self.ax2.text(0.2, 0.5, 'Depth (m bsl.)', fontsize=8, ha='center', va='center', rotation=90)
        txt.set_clip_on(False)
        self.ax2.axis('off')
        #   plot an empty borehole plot
        #   define the top and bottom elevation lists - matching the database discretization
        self.top_lst = np.arange(0, 100, 5).tolist() + np.arange(100, 200, 10).tolist() + np.arange(200, 500, 25).tolist() + \
                  np.arange(500, 1000, 50).tolist() + np.arange(1000, 1500, 100).tolist()
        self.bot_lst = np.arange(5, 100, 5).tolist() + np.arange(100, 200, 10).tolist() + np.arange(200, 500, 25).tolist() + \
                  np.arange(500, 1000, 50).tolist() + np.arange(1000, 1600, 100).tolist()
        #   create the individual lithology profiles
        for k in range(len(self.top_lst)):
            key = 'nd'
            #   find color, hatch and the depth from and to for given litho class
            color = self.litho_class_styles[key]['color']
            hatch = self.litho_class_styles[key]['hatch']
            y_coord = [self.top_lst[k], self.bot_lst[k]]
            self.ax1.fill_betweenx(y_coord, 0, [1, 1], facecolor=color, hatch=hatch)
            self.ax1.plot([0, 1], [self.top_lst[k], self.top_lst[k]], color='blue', lw=0.1)
            self.ax1.plot([0, 1], [self.bot_lst[k], self.bot_lst[k]], color='blue', lw=0.1)
        self.ax1.set_xticks([])
        self.ax1.set_ylim(bottom=1500, top=0)
        self.ax1.tick_params(axis='y', labelsize=8)
        #   plot the canvas
        self.canvas_to_print = FigureCanvas(self.fig)
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        self.canvas_to_print.setSizePolicy(sizePolicy)
        self.canvas_to_print.draw()

    def zoomToFull(self):
        self.ax1.set_ylim(bottom=self.bot_lst[-1], top=0)
        self.canvas_to_print.draw()

    #   zoom to full profile - from 0 to 1500m

    #   zoom to last lithological class defined - cut all the non-defined cells at the bottom
    def zoomToLitho(self, litho_lst):
        #   loop through the lithological list and find the first non-nan value and then the bot elevation to zoom
        for j in range(len(litho_lst) - 1, 0, -1):
            val = litho_lst[j]
            key = self.get_key(val)
            if key != 'nd':
                break
        #   define the axis limits
        self.ax1.set_ylim(bottom=self.bot_lst[j], top=0)
        self.canvas_to_print.draw()

    #   function to find a key in the lithology dictionary
    def get_key(self, val_in):
        for key, value in self.litho_class_styles.items():
            #if val_in == value['lith_full']:
            if val_in == value['lith_num']:
                return key

    #   plot the borehole lithology plot
    def plotBoreholeLithology(self, litho_lst):
        #   loop through the lithology and plot the individual lithological depth profiles
        for k in range(len(litho_lst)):
            val = litho_lst[k]
            key = self.get_key(val)
            #   find color, hatch and the depth from and to for given litho class
            color = self.litho_class_styles[key]['color']
            hatch = self.litho_class_styles[key]['hatch']
            y_coord = [self.top_lst[k], self.bot_lst[k]]
            self.ax1.fill_betweenx(y_coord, 0, [1, 1], facecolor=color, hatch=hatch)
            self.ax1.plot([0, 1], [self.top_lst[k], self.top_lst[k]], color='blue', lw=0.25)
            self.ax1.plot([0, 1], [self.bot_lst[k], self.bot_lst[k]], color='blue', lw=0.25)
        self.ax1.set_xticks([])
        #   redraw the borehole plot
        self.canvas_to_print.draw()


#   define class for the legend plotting area
class LithologyLegendPlotCanvas(FigureCanvas):

    def __init__(self, parent=None, width=2, height=6, dpi=300):

        #   define the lithological classes styles and names
        self.litho_class_styles = {
            'su': {'lith': 'su', 'lith_full': 'unconsolidated sediments', 'lith_num': 100, 'hatch': '',
                   'color': 'gold'},
            'su_ad': {'lith': 'su_ad', 'lith_full': 'alluvial deposits', 'lith_num': 101, 'hatch': '-.',
                      'color': '#ffd757'},
            'su_ds': {'lith': 'su_ds', 'lith_full': 'dune sands', 'lith_num': 102, 'hatch': '-.', 'color': '#fcc100'},
            'su_lo': {'lith': 'su_lo', 'lith_full': 'loess', 'lith_num': 103, 'hatch': '-.', 'color': '#8a6a00'},
            'su_mx': {'lith': 'su_mx', 'lith_full': 'sand - mixed grain size', 'lith_num': 104, 'hatch': 'O',
                      'color': '#ffd95f'},
            'su_ss': {'lith': 'su_ss', 'lith_full': 'sand - coarse grained', 'lith_num': 105, 'hatch': 'o',
                      'color': '#ffd95f'},
            'su_sh': {'lith': 'su_sh', 'lith_full': 'sand - fine grained', 'lith_num': 106, 'hatch': '.',
                      'color': '#ffd95f'},
            'su_cl': {'lith': 'su_cl', 'lith_full': 'clay', 'lith_num': 107, 'hatch': '.', 'color': 'grey'},
            'su_gr': {'lith': 'su_gr', 'lith_full': 'gravel', 'lith_num': 108, 'hatch': 'o', 'color': 'olivedrab'},
            'su_sl': {'lith': 'su_sl', 'lith_full': 'silt', 'lith_num': 109, 'hatch': '..', 'color': 'lawngreen'},
            'ss': {'lith': 'ss', 'lith_full': 'siliclastic sedimentary rocks', 'lith_num': 200, 'hatch': '',
                   'color': 'forestgreen'},
            'ss_gr': {'lith': 'ss_gr', 'lith_full': 'siliclastic sedimentary rocks -\ncoarse grained (conglomerate)',
                      'lith_num': 201, 'hatch': 'o', 'color': 'forestgreen'},
            'ss_mx': {'lith': 'ss_ss', 'lith_full': 'siliclastic sedimentary rocks -\nmedium grained (sandstone)',
                      'lith_num': 202, 'hatch': 'O', 'color': 'forestgreen'},
            'ss_cl': {'lith': 'ss_cl', 'lith_full': 'siliclastic sedimentary rocks -\nfine grained (mudstone)',
                      'lith_num': 203, 'hatch': '.', 'color': 'forestgreen'},
            'sm': {'lith': 'sm', 'lith_full': 'mixed sedimentary rocks', 'lith_num': 210, 'hatch': 'o-',
                   'color': 'turquoise'},
            'sc': {'lith': 'sc', 'lith_full': 'carbonate sedimentary rocks', 'lith_num': 220, 'hatch': 'o-',
                   'color': 'aqua'},
            'sc_we': {'lith': 'sc_we', 'lith_full': 'carbonate sedimentary rocks -\nweathered', 'lith_num': 221, 'hatch': 'x',
                   'color': 'aqua'},
            'vb': {'lith': 'vb', 'lith_full': 'basic volcanic rocks', 'lith_num': 300, 'hatch': 'o',
                   'color': 'darkorange'},
            'vi': {'lith': 'vi', 'lith_full': 'intermediate volcanic rocks', 'lith_num': 310, 'hatch': 'O',
                   'color': 'darkorange'},
            'va': {'lith': 'va', 'lith_full': 'acid volcanic rocks', 'lith_num': 320, 'hatch': 'oo',
                   'color': 'darkorange'},
            'pb': {'lith': 'pb', 'lith_full': 'basic plutonic rocks', 'lith_num': 400, 'hatch': 'o',
                   'color': 'fuchsia'},
            'pi': {'lith': 'pi', 'lith_full': 'intermediate plutonic rocks', 'lith_num': 410, 'hatch': 'O',
                   'color': 'fuchsia'},
            'pa': {'lith': 'pa', 'lith_full': 'acid plutonic rocks', 'lith_num': 420, 'hatch': 'oo',
                   'color': 'fuchsia'},
            'mt': {'lith': 'mt', 'lith_full': 'metamorphic rocks', 'lith_num': 500, 'hatch': '-|', 'color': 'plum'},
            'mt_am': {'lith': 'mt_am', 'lith_full': 'mafic metamorphic rocks', 'lith_num': 501, 'hatch': 'x', 'color': 'plum'},
            'py': {'lith': 'py', 'lith_full': 'pyroclastics', 'lith_num': 600, 'hatch': 'x', 'color': 'crimson'},
            'ev': {'lith': 'ev', 'lith_full': 'evaporites', 'lith_num': 700, 'hatch': 'o', 'color': 'darkorchid'},
            'rock': {'lith': 'rock', 'lith_full': 'rock', 'lith_num': 800, 'hatch': '++', 'color': 'dimgrey'},
            'soil': {'lith': 'soil', 'lith_full': 'soil', 'lith_num': 900, 'hatch': 'o', 'color': 'tan'},
            'coal': {'lith': 'coal', 'lith_full': 'coal', 'lith_num': 1000, 'hatch': '-|', 'color': 'black'},
            'nd': {'lith': 'nd', 'lith_full': 'not defined', 'lith_num': 0, 'hatch': 'x', 'color': 'snow'}}

        #   define the sublots in the figure
        self.fig = plt.Figure(figsize=(2,8))
        self.ax2 = plt.subplot2grid((1, 1), (0, 0), fig=self.fig)  # dbase borehole
        self.ax2.set_position([0.05, 0.05, 0.9, 0.95])  # [left, bottom, width, height]

        #   create legend from the dictionary
        self.patchList = []
        for key in self.litho_class_styles:
            data_key = mpatches.Patch(facecolor=self.litho_class_styles[key]['color'], hatch=self.litho_class_styles[key]['hatch'],
                                      label=self.litho_class_styles[key]['lith'] + ': ' + self.litho_class_styles[key]['lith_full'])
            self.patchList.append(data_key)

        #   define the legend
        legend = self.ax2.legend(handles=self.patchList, ncol=1, frameon=False, fontsize=7, handlelength=3, labelspacing=1.25,
                            title="Database lithological classification", title_fontsize=9)
        legend.get_frame().set_edgecolor('black')
        legend.get_frame().set_linewidth(.75)
        self.ax2.axis('off')

        #   define the size of the patches (rectangles) showing the lithology classes
        for patch in legend.get_patches():
            patch.set_height(12)
            patch.set_y(-4)

        #   plot the canvas
        self.canvas_to_print = FigureCanvas(self.fig)
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(1)
        self.canvas_to_print.setMinimumSize(self.canvas_to_print.size())
        self.canvas_to_print.setSizePolicy(sizePolicy)
        self.canvas_to_print.draw()

"""
    def on_draw(self, event):
        self.xlim = self.axes.get_xlim()
        self.ylim = self.axes.get_ylim()

    def plotConcProfile(self, netcf_obj, ts, rcp_sc, dem_sc, xmin, xmax, ymin, ymax):
        #   transform the DEM texts into the values in th netcdf
        if dem_sc == 'GEBCO':
            dem_sc = 'gebco'
        elif dem_sc == 'TopoDEM':
            dem_sc = 'merit'
        elif dem_sc == 'CoastalDEM':
            dem_sc = 'coastal'
        #   same with the RCP scenarios
        # rcp_sc = rcp_sc.replace('.', '')
        if rcp_sc == '2.6':
            rcp_sc = '26'
        elif rcp_sc == '4.5':
            rcp_sc = '45'
        elif rcp_sc == '8.5':
            rcp_sc = '85'

        #   read in the x, y coordinates and the salinity
        self.x_coord, self.y_coords = netcf_obj['x'].values.tolist(), netcf_obj['y'].values.tolist()
        #   select the right RCP and DEM scenario salinity, and divide the values by 100 to get the right units
        salinity = netcf_obj.sel(time=ts).sel(dem=dem_sc).sel(rcp=rcp_sc)['salinity'].values[0] / 100.
        salinity[salinity < 0] = np.nan
        self.ax3.clear()
        #   add the plot itself
        self.im = self.ax3.imshow(salinity, aspect='auto', interpolation='none', cmap=self.cmap, norm=self.norm, \
                                  extent=(self.x_coord[0], self.x_coord[-1], min(self.y_coords) + 5.0,
                                          max(self.y_coords) + 5.0), animated=True)  # vmin = 0, vmax = 35.0,
        self.ax3.set_xlim([self.x_coord[0], self.x_coord[-1]])
        self.ax3.set_ylim([min(self.y_coords) - 5.0, max(self.y_coords) + 5.0])
        #       add the grid and coastline position - current sea level position
        x_major_ticks = np.arange(math.floor(self.x_coord[0] / 5.) * 5., math.ceil(self.x_coord[-1]), 5.0)[1:]
        x_minor_ticks = np.arange(math.floor(self.x_coord[0] / 1.) * 1., math.ceil(self.x_coord[-1]), 1.0)
        y_major_ticks = np.arange(math.floor((min(self.y_coords) + 5.0) / 100.) * 100., max(self.y_coords) + 5.0 + 1.0,
                                  100.0)[1:]
        y_minor_ticks = np.arange(math.floor((min(self.y_coords) + 5.0) / 50.) * 50., max(self.y_coords) + 5.0 + 1.0,
                                  50.0)
        self.ax3.set_xticks(x_major_ticks)
        self.ax3.set_xticks(x_minor_ticks, minor=True)
        self.ax3.set_yticks(y_major_ticks)
        self.ax3.set_yticks(y_minor_ticks, minor=True)
        self.ax3.grid(which='minor', alpha=0.2)
        self.ax3.grid(which='major', alpha=0.5)
        self.zoom(xmin, xmax, ymin, ymax)
        plt.tight_layout()
        #   for testing purposes these two lines below are for saving the canvas
        # canvas = FigureCanvas(fig)
        # canvas.print_figure(r'g:\_modelbuilder\test_plot.png', dpi=200)
        # self.ax3.set_xlim(self.xlim)
        # self.ax3.set_ylim(self.ylim)
        # self.canvas_to_print.draw()
        # return canvas_to_print

    def plotConcProfile_SEAWAT_output(self, netcf_obj, ts, xmin, xmax, ymin, ymax):
        #   read in the x, y coordinates and the salinity
        self.x_coord, self.y_coords = netcf_obj['x'].values.tolist(), netcf_obj['y'].values.tolist()
        #   select the right RCP and DEM scenario salinity, and divide the values by 100 to get the right units
        salinity = netcf_obj.sel(time=ts)['solute concentration'].values
        # salinity[salinity < 0] = np.nan
        salinity[salinity > 100] = np.nan
        salinity[salinity > 35] = 35
        self.ax3.clear()
        #   add the plot itself
        self.im = self.ax3.imshow(salinity, aspect='auto', interpolation='none', cmap=self.cmap, norm=self.norm, \
                                  extent=(self.x_coord[0], self.x_coord[-1], min(self.y_coords) + 5.0,
                                          max(self.y_coords) + 5.0), animated=True)  # vmin = 0, vmax = 35.0,
        self.ax3.set_xlim([self.x_coord[0], self.x_coord[-1]])
        self.ax3.set_ylim([min(self.y_coords) - 5.0, max(self.y_coords) + 5.0])
        #       add the grid and coastline position - current sea level position
        x_major_ticks = np.arange(math.floor(self.x_coord[0] / 5.) * 5., math.ceil(self.x_coord[-1]), 5.0)[1:]
        x_minor_ticks = np.arange(math.floor(self.x_coord[0] / 1.) * 1., math.ceil(self.x_coord[-1]), 1.0)
        y_major_ticks = np.arange(math.floor((min(self.y_coords) + 5.0) / 100.) * 100., max(self.y_coords) + 5.0 + 1.0,
                                  100.0)[1:]
        y_minor_ticks = np.arange(math.floor((min(self.y_coords) + 5.0) / 50.) * 50., max(self.y_coords) + 5.0 + 1.0,
                                  50.0)
        self.ax3.set_xticks(x_major_ticks)
        self.ax3.set_xticks(x_minor_ticks, minor=True)
        self.ax3.set_yticks(y_major_ticks)
        self.ax3.set_yticks(y_minor_ticks, minor=True)
        self.ax3.grid(which='minor', alpha=0.2)
        self.ax3.grid(which='major', alpha=0.5)
        self.zoom(xmin, xmax, ymin, ymax)
        plt.tight_layout()
        #   for testing purposes these two lines below are for saving the canvas
        # canvas = FigureCanvas(fig)
        # canvas.print_figure(r'g:\_modelbuilder\test_plot.png', dpi=200)
        # self.ax3.set_xlim(self.xlim)
        # self.ax3.set_ylim(self.ylim)
        # self.canvas_to_print.draw()
        # return canvas_to_print
"""