"""
    Script that contains different lithology strings and classes and merges them into the simplified and generalized
    GERBIL lithology classes. This helps the user to indentify the right GERBIL lithological class in case they stumble
    on a description that is difficult to interpret.
"""

import re

litho_class_styles = {
    'su': {'lith': 'su', 'lith_full': 'unconsolidated sediments', 'lith_num': 100, 'hatch': '',
           'color': 'gold'},
    'su_ad': {'lith': 'su_ad', 'lith_full': 'alluvial deposits', 'lith_num': 101, 'hatch': '-.',
              'color': '#ffd757'},
    'su_ds': {'lith': 'su_ds', 'lith_full': 'dune sands', 'lith_num': 102, 'hatch': '-.', 'color': '#fcc100'},
    'su_lo': {'lith': 'su_lo', 'lith_full': 'loess', 'lith_num': 103, 'hatch': '-.', 'color': '#8a6a00'},
    'su_mx': {'lith': 'su_mx', 'lith_full': 'sand - mixed grain size', 'lith_num': 104, 'hatch': 'O',
              'color': '#ffd95f'},
    'su_ss': {'lith': 'su_ss', 'lith_full': 'sand - coarse grained', 'lith_num': 105, 'hatch': 'o',
              'color': '#ffd95f'},
    'su_sh': {'lith': 'su_sh', 'lith_full': 'sand - fine grained', 'lith_num': 106, 'hatch': '.',
              'color': '#ffd95f'},
    'su_cl': {'lith': 'su_cl', 'lith_full': 'clay', 'lith_num': 107, 'hatch': '.', 'color': 'grey'},
    'su_gr': {'lith': 'su_gr', 'lith_full': 'gravel', 'lith_num': 108, 'hatch': 'o', 'color': 'olivedrab'},
    'su_sl': {'lith': 'su_sl', 'lith_full': 'silt', 'lith_num': 109, 'hatch': '..', 'color': 'lawngreen'},
    'ss': {'lith': 'ss', 'lith_full': 'siliclastic sedimentary rocks', 'lith_num': 200, 'hatch': '',
           'color': 'forestgreen'},
    'ss_gr': {'lith': 'ss_gr', 'lith_full': 'siliclastic sedimentary rocks -\ncoarse grained (conglomerate)',
              'lith_num': 201, 'hatch': 'o', 'color': 'forestgreen'},
    'ss_mx': {'lith': 'ss_ss', 'lith_full': 'siliclastic sedimentary rocks -\nmedium grained (sandstone)',
              'lith_num': 202, 'hatch': 'O', 'color': 'forestgreen'},
    'ss_cl': {'lith': 'ss_cl', 'lith_full': 'siliclastic sedimentary rocks -\nfine grained (mudstone)',
              'lith_num': 203, 'hatch': '.', 'color': 'forestgreen'},
    'sm': {'lith': 'sm', 'lith_full': 'mixed sedimentary rocks', 'lith_num': 210, 'hatch': 'o-',
           'color': 'turquoise'},
    'sc': {'lith': 'sc', 'lith_full': 'carbonate sedimentary rocks', 'lith_num': 220, 'hatch': 'o-',
           'color': 'aqua'},
    'sc_we': {'lith': 'sc_we', 'lith_full': 'carbonate sedimentary rocks -\nweathered', 'lith_num': 221, 'hatch': 'x',
              'color': 'aqua'},
    'vb': {'lith': 'vb', 'lith_full': 'basic volcanic rocks', 'lith_num': 300, 'hatch': 'o',
           'color': 'darkorange'},
    'vi': {'lith': 'vi', 'lith_full': 'intermediate volcanic rocks', 'lith_num': 310, 'hatch': 'O',
           'color': 'darkorange'},
    'va': {'lith': 'va', 'lith_full': 'acid volcanic rocks', 'lith_num': 320, 'hatch': 'oo',
           'color': 'darkorange'},
    'pb': {'lith': 'pb', 'lith_full': 'basic plutonic rocks', 'lith_num': 400, 'hatch': 'o',
           'color': 'fuchsia'},
    'pi': {'lith': 'pi', 'lith_full': 'intermediate plutonic rocks', 'lith_num': 410, 'hatch': 'O',
           'color': 'fuchsia'},
    'pa': {'lith': 'pa', 'lith_full': 'acid plutonic rocks', 'lith_num': 420, 'hatch': 'oo',
           'color': 'fuchsia'},
    'mt': {'lith': 'mt', 'lith_full': 'metamorphic rocks', 'lith_num': 500, 'hatch': '-|', 'color': 'plum'},
    'mt_am': {'lith': 'mt_am', 'lith_full': 'mafic metamorphic rocks', 'lith_num': 501, 'hatch': 'x', 'color': 'plum'},
    'py': {'lith': 'py', 'lith_full': 'pyroclastics', 'lith_num': 600, 'hatch': 'x', 'color': 'crimson'},
    'ev': {'lith': 'ev', 'lith_full': 'evaporites', 'lith_num': 700, 'hatch': 'o', 'color': 'darkorchid'},
    'rock': {'lith': 'rock', 'lith_full': 'rocks', 'lith_num': 800, 'hatch': '++', 'color': 'dimgrey'},
    'soil': {'lith': 'soil', 'lith_full': 'soil', 'lith_num': 900, 'hatch': 'o', 'color': 'tan'},
    'coal': {'lith': 'coal', 'lith_full': 'coal', 'lith_num': 1000, 'hatch': '-|', 'color': 'black'},
    'nd': {'lith': 'nd', 'lith_full': 'not defined', 'lith_num': 0, 'hatch': 'x', 'color': 'snow'}}

#   function that gets the key from the lithology dictionary
def get_key(val_in):
    for key, value in litho_class_styles.items():
        if val_in == value['lith']:
            return(value['lith_full'])

#   the function will take a simple string as input - from the line edit in the Add borehole tab
#   re.IGNORECASE is here in case the string has lower or upper case letters - some borehologs can have all caps etc.
#   litho_str = 'Sandstone'
def translateLithoVal(litho_str):
    #   define the value of the returned litho class (start with not-defined)
    litho_class_out = 'nd'

    #   start the conditional sequence with the sedimentary rocks
    #       siliclastic sedimentary rocks
    if re.search(litho_str, 'Sandstone, Mudstone, Greywacke, Shale, Siltstone, Claystone, Conglomerate, Breccia', re.IGNORECASE):
        if re.search(litho_str, 'Conglomerate, Breccia'):
            litho_class_out = 'ss_gr'
        elif re.search(litho_str, 'Sandstone, Greywacke'):
            litho_class_out = 'ss_mx'
        elif re.search(litho_str, 'Mudstone, Siltstone, Claystone'):
            litho_class_out = 'ss_cl'
        else:
            litho_class_out = 'ss'
    #       carbonate sedimentary rock
    if re.search(litho_str, 'Limestone, Dolomite, Marl, Calcite', re.IGNORECASE):
        if re.search(litho_str, 'weathered'):
            litho_class_out = 'sc_we'
        else:
            litho_class_out = 'sc'
    #       sedimentary rocks
    if re.search(litho_str, 'Mixed, sedimentary rock', re.IGNORECASE):
        litho_class_out = 'sm'

    #   deal with hard rock lithology classes
    #       pyroclastics
    if re.search(litho_str, 'Tuff, Volcanic, Ash', re.IGNORECASE):
        litho_class_out = 'py'
    #       evaporaties
    if re.search(litho_str, 'Gypsum, Halite, Anhy, Salt pan', re.IGNORECASE):
        litho_class_out = 'ev'
    #       acid volcanics
    if re.search(litho_str, 'Rhyolite, Trachyte, Dacite', re.IGNORECASE):
        litho_class_out = 'va'
    #       basic volcanics
    if re.search(litho_str, 'Basalt, Tephrite, Tholeit, Lamprophyr', re.IGNORECASE):
        litho_class_out = 'vb'
    #       intermediate volcanics
    if re.search(litho_str, 'Andesite', re.IGNORECASE):
        litho_class_out = 'vi'
    #       acid plutonics
    if re.search(litho_str, 'Granite', re.IGNORECASE):
        litho_class_out = 'pa'
    #       basic plutonics
    if re.search(litho_str, 'Gabbro, Peridotite, Norite, Ophiolite', re.IGNORECASE):
        litho_class_out = 'pb'
    #       intermediate plutonics
    if re.search(litho_str, 'Diorite, Monzonite, Syenite', re.IGNORECASE):
        litho_class_out = 'pi'
    #       metamoprhics
    if re.search(litho_str, 'Marble, Amphibolite, Metamorph, Quartzite, Slate, Schist, Shist, Phyllite,\
                            Olivine, Pyroxene, Amphibole, Biotite, Plagioclase', re.IGNORECASE):
        if re.search(litho_str, 'Mafic, Olivine, Pyroxene, Amphibole, Biotite, Plagioclase', re.IGNORECASE):
            litho_class_out = 'mt_am'
        else:
            litho_class_out = 'mt'

    #   now deal with the unconsolidated sediments
    #       make initial selection of the lithological classes
    if re.search(litho_str, 'Sand, Clay, Gravel, Silt, Mud', re.IGNORECASE):
        if not re.search(litho_str, 'Stone', re.IGNORECASE):
            #   coarse sand
            if re.search(litho_str, 'Coarse', re.IGNORECASE) and re.search(litho_str, 'Sand', re.IGNORECASE):
                litho_class_out = 'su_ss'
            elif re.search(litho_str, 'Mixed', re.IGNORECASE) and re.search(litho_str, 'Sand', re.IGNORECASE):
                litho_class_out = 'su_mx'
            elif re.search(litho_str, 'Fine', re.IGNORECASE) and re.search(litho_str, 'Sand', re.IGNORECASE):
                litho_class_out = 'su_sh'
            #   gravel
            elif re.search(litho_str, 'Sand', re.IGNORECASE):
                litho_class_out = 'su_mx'
            #   clay
            elif re.search(litho_str, 'Clay', re.IGNORECASE) and not re.search(litho_str, 'Sand', re.IGNORECASE):
                litho_class_out = 'su_cl'
            #   silt
            elif re.search(litho_str, 'Silt', re.IGNORECASE) and not re.search(litho_str, 'Sand', re.IGNORECASE):
                litho_class_out = 'su_sl'
            #   Alluvial deposits
            elif re.search(litho_str, 'Alluv', re.IGNORECASE):
                litho_class_out = 'su_ad'
            #   Dune sands
            elif re.search(litho_str, 'Dune', re.IGNORECASE) and re.search(litho_str, 'Sand', re.IGNORECASE):
                litho_class_out = 'su_ds'
            #   Loess
            elif re.search(litho_str, 'Loes', re.IGNORECASE):
                litho_class_out = 'su_lo'
            #   otherwise just return the overall su classe
            else:
                litho_class_out = 'su'

    #   if there is still no class found then go to the last 4 classes and end with not defined as last resort
    #   only look further if the out lithological class is still not defined
    if litho_class_out == 'nd':
        if re.search(litho_str, 'Rock, Stone', re.IGNORECASE):
            litho_class_out = 'rock'
        elif re.search(litho_str, 'Soil', re.IGNORECASE):
            litho_class_out = 'soil'
        elif re.search(litho_str, 'Coal', re.IGNORECASE):
            litho_class_out = 'coal'
        else:
            litho_class_out = 'ns'

    #   find the full string in the dictionary
    litho_str_out = get_key(litho_class_out)
    return litho_str_out
