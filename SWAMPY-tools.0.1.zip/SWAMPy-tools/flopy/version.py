# flopy version file automatically created using...make-release.py
# created on...May 31, 2019 19:46:17

major = 3
minor = 2
micro = 12
__version__ = '{:d}.{:d}.{:d}'.format(major, minor, micro)
